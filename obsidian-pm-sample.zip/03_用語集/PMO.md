## 定義

Project Management Office(プロジェクト管理オフィス)。複数案件を横断的に支援・統制する組織機能。本ヴォルトの「[[00_ダッシュボード/全案件一覧|全案件一覧]]」がPMO的な俯瞰の役割を担う。

## この用語が登場する案件

```dataview
LIST
FROM "01_案件"
WHERE contains(file.outlinks, this.file.link)
```
